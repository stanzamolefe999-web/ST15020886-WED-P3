// ============================================================
// Kalahari Roots — site script
// Handles: mobile nav toggle, product category filtering,
// and lightweight client-side form validation.
// ============================================================

document.addEventListener("DOMContentLoaded", function () {

  /* ---------- Mobile navigation toggle ---------- */
  var navToggle = document.querySelector(".nav-toggle");
  var navLinks = document.querySelector(".nav-links");
  if (navToggle && navLinks) {
    navToggle.addEventListener("click", function () {
      var isOpen = navLinks.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });
  }

  /* ---------- Product category filter (products.html) ---------- */
  var filterButtons = document.querySelectorAll(".filter-btn");
  var productCards = document.querySelectorAll(".product-card");
  if (filterButtons.length && productCards.length) {
    filterButtons.forEach(function (btn) {
      btn.addEventListener("click", function () {
        filterButtons.forEach(function (b) { b.classList.remove("active"); });
        btn.classList.add("active");
        var category = btn.getAttribute("data-category");

        productCards.forEach(function (card) {
          var matches = category === "all" || card.getAttribute("data-category") === category;
          card.style.display = matches ? "" : "none";
        });
      });
    });
  }

  /* ---------- Pre-fill product interest from a product page link ---------- */
  var productField = document.getElementById("product-interest");
  if (productField) {
    var params = new URLSearchParams(window.location.search);
    var productParam = params.get("product");
    if (productParam) {
      productField.value = productParam;
    }
  }

  /* ---------- Form validation: Enquiry + Contact forms ---------- */
  var forms = document.querySelectorAll("form[data-validate]");
  forms.forEach(function (form) {
    form.addEventListener("submit", function (event) {
      event.preventDefault();
      var valid = true;

      var fields = form.querySelectorAll("[required]");
      fields.forEach(function (field) {
        var row = field.closest(".form-row");
        var isEmpty = field.value.trim() === "";
        var isBadEmail = field.type === "email" && field.value.trim() !== "" && !/^\S+@\S+\.\S+$/.test(field.value);

        if (isEmpty || isBadEmail) {
          valid = false;
          if (row) row.classList.add("invalid");
        } else if (row) {
          row.classList.remove("invalid");
        }
      });

      var successBox = form.parentElement.querySelector(".form-success");
      if (valid) {
        form.reset();
        if (successBox) {
          successBox.classList.add("show");
          successBox.setAttribute("tabindex", "-1");
          successBox.focus();
        }
      } else if (successBox) {
        successBox.classList.remove("show");
      }
    });
  });

});
